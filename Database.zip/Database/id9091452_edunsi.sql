-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 01, 2019 at 05:48 PM
-- Server version: 10.3.13-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id9091452_edunsi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'edunsi', 'admin@edunsi.com', 'edunsi123');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `score` varchar(255) NOT NULL DEFAULT '10,10,10',
  `level` varchar(32) NOT NULL DEFAULT '1',
  `tgl` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `score`, `level`, `tgl`) VALUES
(6, 'user124', 'user124', 'user124@gmail.com', '66000,10,330', '3', '2019-03-17 09:37:54'),
(17, 'alberth', 'alberth1234', 'alberthzeriko@gmail.com', '10,10,10', '1', '2019-03-24 08:11:05'),
(18, 'liana hutabarat', 'liana1234', 'lianahutabarat@gmail.com', '20,10,10', '1', '2019-03-24 14:08:01'),
(20, 'dion rumbo', 'dion12345', 'dionrumahorbo81@gmail.com', '81246200,10,10', '2', '2019-03-26 16:29:56'),
(21, 'samuel simanjuntak', 'samuel1234', 'samuelsimanjuntak059@gmail.com', '85662500,10,10', '2', '2019-03-26 16:32:23'),
(22, 'sarda tambunan', 'sarda1234', 'sardaf095@gmail.com', '83953500,10,10', '2', '2019-03-27 14:58:32'),
(23, 'andina marpaung', 'andina1234', 'asdmarpaung@gmail.com', '83378400,101647000,230', '3', '2019-03-27 15:01:39'),
(24, 'Rosianna Manurung', 'anna1234', 'rosiannamnrg@gmail.com', '86186000,10,10', '2', '2019-03-27 15:11:00'),
(25, 'Imelda Simorangkir', 'melda1234', 'Imeldasimorangkir34@yahoo.com', '82877500,10,10', '2', '2019-03-27 15:14:04'),
(27, 'newuser', 'new', 'newuser@gmail.com', '10,10,10', '1', '2019-03-27 21:25:50'),
(28, 'helen', 'helen1234', 'helenfrisely925@gmail.com', '139300,10,10', '2', '2019-03-31 15:22:55'),
(29, 'helen frisely', 'helen1234', 'helenfrisely925@gmail.com', '10,10,10', '1', '2019-04-01 03:15:43');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE `user_log` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tgl_bermain` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`id`, `id_user`, `tgl_bermain`) VALUES
(1, 6, '2019-04-01 17:45:53'),
(2, 17, '2019-04-01 17:45:53'),
(3, 18, '2019-04-01 17:47:07'),
(4, 20, '2019-04-01 17:47:07'),
(5, 21, '2019-04-01 17:47:07'),
(6, 22, '2019-04-01 17:47:07'),
(7, 23, '2019-04-01 17:47:07'),
(8, 24, '2019-04-01 17:47:07'),
(9, 25, '2019-04-01 17:47:07'),
(10, 26, '2019-04-01 17:47:50'),
(11, 27, '2019-04-01 17:47:50'),
(12, 28, '2019-04-01 17:48:08'),
(13, 29, '2019-04-01 17:48:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_log`
--
ALTER TABLE `user_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `user_log`
--
ALTER TABLE `user_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
